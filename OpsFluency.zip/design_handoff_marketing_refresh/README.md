# Handoff: OpsFluency Marketing Refresh ("Blueprint")

## Overview
A visual refresh of the OpsFluency consultancy marketing site. It keeps the existing
**Steel & Signal** brand (teal `#14B8A6`, Chakra Petch / Inter / JetBrains Mono, light+dark)
but fixes two problems the current build has:

1. **Sections blur together** — every section used `bg-dc-raised` (≈ the page bg), so the page
   read as one undifferentiated wash.
2. **No depth / "pop"** — flat cards, hairline borders, no elevation or focal visuals.

The refresh introduces a **"Blueprint" system**: oversized ghost section numerals, framed panels
with corner-tick detailing, soft layered shadows, dashed "dimension" dividers, mono micro-labels,
and one clear product/credibility visual per page. It also **refocuses the site on the consulting
practice** and pulls the SaaS/app material back to where it belongs (the Tools page + one
"Platform Setup" service lane).

## About the Design Files
The files in this bundle (`*.dc.html`) are **design references**, not production code. They are
self-contained HTML prototypes that show the intended look, layout, copy, and interactions.

**Your task is to recreate these designs in the existing Next.js codebase** (`app/(marketing)/*`
and `components/marketing/*`), using the established patterns already there:
- Tailwind v4 + the tokens defined in `app/globals.css` (`--color-brand`, `--color-dc-*`,
  `--color-signal-*`, `--font-display/sans/mono`).
- `next/font` families already wired on `<html>`.
- The existing `MarketingNav`, `MarketingFooter`, `Container`, `Button`, `MotionSection`
  primitives. **Do not** ship the nav/footer/control-bar that are inlined in the prototypes
  (see "What to ignore" below).
- The existing `.dark` class theme mechanism (the prototypes' Light/Dark button is only a
  preview aid; real theme switching already exists via `ThemeToggle`).

Follow the rules in `design-system/opsfluency/MASTER.md` — especially §4 Elevation (light mode =
soft shadows, **dark mode = edges, not shadows**) and §2 Typography.

## Fidelity
**High-fidelity.** Final colors, type, spacing, and interactions. Recreate pixel-faithfully using
the codebase's tokens and components. Where a prototype value maps to an existing token, **use the
token** (mapping table below) rather than the raw hex.

---

## The Blueprint system (shared primitives to build first)

Build these once and reuse on every page. Suggested new files under `components/marketing/`.

### 1. `SectionKicker` + ghost-numeral `SectionHeader`
Every numbered section opens with a giant outline numeral beside a kicker + heading.

- **Ghost numeral**: `font-display`, `font-weight:700`, `font-size: clamp(46px,7vw,92px)`,
  `line-height:.78`, `letter-spacing:-0.02em`, `color: transparent`,
  `-webkit-text-stroke: 1.5px var(--color-dc-edge-2)`. (Outline only — it sits to the left of the
  header on desktop, gap `clamp(16px,2.5vw,32px)`.)
- **Kicker**: a flex row, `gap:10px` — an **8×8px solid teal square** (`background: var(--color-brand)`,
  not a circle) + an eyebrow: `font-display`, `12px`, `font-weight:600`,
  `letter-spacing:0.2em`, `text-transform:uppercase`, `color: var(--color-brand)`.
- **Heading (h2)**: `font-display`, `font-weight:600`, `font-size: clamp(26px,3.4vw,44px)`,
  `line-height:1.08`, `letter-spacing:-0.02em`, `color: var(--color-dc-text)`.
- **Subhead (optional)**: `font-sans`, `16px`, `line-height:1.6`, `color: var(--color-dc-text-2)`,
  `max-width: 560px`.

### 2. `FramedPanel` (the core card)
- `background: var(--color-dc-surface)`, `border: 1px solid var(--color-dc-edge)` (use
  `--color-dc-edge-2` for emphasis panels), **`border-radius: 4–6px`** (sharp, "blueprint" — NOT the
  12px `rounded-xl` used elsewhere; sharper corners are part of this look).
- **Shadow (light only)**: `0 1px 2px rgba(15,17,23,0.04), 0 8px 24px -14px rgba(15,17,23,0.12)`.
  **Dark mode: no shadow, rely on the border** (per MASTER §4).
- **Hover (interactive cards)**: `transform: translateY(-3px)` + deepen the second shadow layer to
  `0 16px 36px -14px rgba(15,17,23,0.18)`. 200ms ease.
- **Featured panel**: add `border-top: 3px solid var(--color-brand)` and a soft teal glow
  (`box-shadow: 0 20px 44px -18px rgba(20,184,166,0.4)`), optionally the existing
  `.animate-brand-glow`.

### 3. Corner ticks (the signature detail)
On hero/founder/CTA frames, place 4 absolutely-positioned L-shaped corner marks just outside the
panel's corners: `width/height: 16px`, two adjacent `2px solid var(--color-brand)` borders
(top+left, top+right, bottom+left, bottom+right). On the teal CTA panel they're white at 60% alpha.

### 4. Mono micro-labels
Index/status tags use `font-mono`, `~10–11px`, `letter-spacing:0.1–0.14em`, often uppercase,
`color: var(--color-dc-text-3)` (or `--color-brand` when active). Examples: `S1`, `E1`, `90 DAYS`,
`EN / ES`, `OPERATOR FILE`, `ENGAGEMENT BRIEF`.

### 5. Dashed dividers / connectors
Use `repeating-linear-gradient(90deg, var(--color-dc-edge-2) 0 7px, transparent 7px 14px)` for the
"dimension line" behind the How-it-works stepper, and `1px dashed var(--color-dc-edge-2)` between a
quote and its response.

### 6. Contained teal CTA (replaces full-bleed gradient on most pages)
A rounded (`8px`) **contained** panel (inside a `max-w` container, not full-bleed) with
`background: linear-gradient(135deg, var(--color-brand), var(--color-brand-dim))`, white text,
white 60%-alpha corner ticks, centered heading/subhead/buttons. (Home keeps this contained
treatment too.)

---

## Token mapping (prototype var → codebase token)

| Prototype CSS var | Use this in code | Notes |
|---|---|---|
| `--bg` | `--color-dc-bg` | Prototype nudged it slightly cooler (`#F4F6FA`) for clearer section steps; optional. |
| `--surface` | `--color-dc-surface` | `#FFFFFF` / dark `#141720` |
| `--raised` | `--color-dc-raised` | Used sparingly (insets, enterprise card). Separation comes mainly from borders + framing, so the existing `--color-dc-raised` is fine as-is. |
| `--text` | `--color-dc-text` | |
| `--text2` | `--color-dc-text-2` | |
| `--text3` | `--color-dc-text-3` | |
| `--edge` | `--color-dc-edge` | |
| `--edge2` | `--color-dc-edge-2` | ghost-numeral stroke, input borders |
| `--color-brand` / `-hover` / `-dim` | same names | unchanged |
| `--sig-ok` / `-warn` / `-live` / `-urgent` | `--color-signal-ok` / `-warn` / `-live` / `-urgent` | status dots, "Available now", before/after |
| brand-on-button text `#04110F` | keep | near-black ink that meets contrast on teal |

Fonts: `--font-display` = Chakra Petch, `--font-sans` = Inter, `--font-mono` = JetBrains Mono
(all already loaded).

---

## Per-page changes

Each prototype maps to an existing route. Below is the **delta** from what's in the repo today.
(Where a section is "unchanged in content," only the Blueprint styling/treatment changes.)

### Home — `app/(marketing)/page.tsx` + `components/marketing/home/*`
New section order: **Hero → CredibilityStrip → Problem → Services → HowIWork → Founder → FinalCTA.**
- **REMOVE `HomeSolution`** (the "Three things nobody else offers" bilingual-SOP/QR/comms trio — that's app/platform, it moves off the consulting home).
- **REMOVE `HomePricingTeaser`** (SaaS tiers don't belong on the consulting home; pricing lives on `/pricing`).
- **`HomeHero`**: keep the headline/subhead/CTAs. Replace the *secondary* CTA "See the platform" →
  **"See how I work"**. Replace the hero's product/dashboard visual with a **"Facility readout"**
  panel (dark `--band` card): mono title `FACILITY READOUT · 90 DAYS`, status `ON TRACK`, 3 outcome
  rows (Order accuracy `99.2%` ▲2.1 / On-time dispatch `98%` ▲6 / Lost-time incidents `0` ✓), a
  12-bar trend (`WEEKLY OUTPUT · 12 WKS`), plus two floating chips: `17 hrs/week recovered`
  (brand-glow) and `Runs without me on site` (signal-ok dot). These are **consulting outcomes**, not
  app UI.
- **`HomeHowItWorks` → "How I work"** (rename concept): replace the app workflow
  (Upload → AI converts → Worker scans) with the **consulting engagement**: **01 Diagnose ·
  02 Build & train · 03 Hand off**, heading "Diagnose. Build. Hand off." Icons: search, wrench,
  circle-check.
- **`HomeFinalCTA`**: drop "Try the platform free"; secondary becomes **"See my services"**.
  Reword subhead away from "consultant, a platform, or both."
- Problem / Services / Founder / CredibilityStrip: same content, Blueprint treatment
  (ghost numerals `01/02/03`, framed cards, corner ticks on the founder panel).

### Services — `components/marketing/services/*`
Content already correct (3 engagements, no dollar amounts). Apply Blueprint: ghost numerals
(`01 The engagements`, `02 Compare engagements`), framed tier cards with `S1/S2/S3` mono tags,
Fractional featured (teal top-bar + glow + centered "Most requested" pill), the comparison table in
a framed wrapper with the **Fractional column tinted** `rgba(20,184,166,0.05)` and a 3px teal top
border, contained teal CTA. Hero gains a right-side **"Engagement index"** framed panel (S1/S2/S3
list, S2 highlighted).

### About — `components/marketing/about/*`
Blueprint editorial. Hero = prose left + **founder portrait placeholder** (4:5, corner ticks,
`ROB · FOUNDER` caption) + an **"Operator file"** mini-panel (Experience 20 yrs / Path Floor → Dir.
Ops / Sites 3 simultaneous). Sections: `01 The story` (long-form prose, indented column, three
oversized teal-left-border pull-quotes), a framed **teal-tinted Thesis callout** with corner ticks,
`02 Mission` (3 numbered framed cards), `03 How I work` (numbered list with divider rules),
`04 Roadmap` (two framed columns; "Shipping now" = signal-ok heartbeat dot, "Next" = signal-warn
calm-pulse dot), contained teal CTA.

### Contact — `components/marketing/contact/*`
Two-column: framed **form panel** (corner ticks) + sidebar (Direct email / LinkedIn channel cards
+ "What happens next" note). Form fields: Name, Work email, Company, Number of employees (select:
Up to 50 / 51 to 150 / 151 to 500 / 500 or more), Message, "What are you trying to fix?" (optional).
On submit → **success state** ("Thanks. Rob will be in touch."). FAQ = 5 items, native
`<details>` disclosure (or the existing Radix accordion); chevron rotates on open.
Inputs: `font-size:16px` (iOS no-zoom), `border-dc-edge-2`, focus = teal border + 3px teal ring.

### Tools — `components/marketing/tools/*`  ← **the one page where the app leads**
Hero = text + **worker-PWA phone mockup** (status bar with offline icon, SOP lines, red
"Lockout required" chip) + a **floating QR print-sheet** (QR matrix). `01 The platform` =
"Available now" framed panel (signal-ok heartbeat dot), 6 capability bullets (2-col), flat-rate
callout ("Starter from $79/mo. Growth from $119. No per-seat fees" + "See full pricing" → /pricing),
"Try it free for 14 days" → `app.opsfluency.com`. `02 What's inside` = 3 feature cards each with a
compact mockup (bilingual EN/ES, QR sheet, phone PWA). `03 In development` = "More tools coming"
(signal-warn calm-pulse dot) → Talk to Rob.

### Pricing — `components/marketing/pricing/*`
Covers **both** ways to work. `01 Consulting` = 3 engagement cards (Operations Consulting /
Fractional [featured] / Custom App Solutions) showing the **engagement model** instead of a price
("Scoped per project", "Scoped to the engagement", "Quoted per project") — no per-seat math.
`02 The platform` = **Annual/Monthly billing toggle** that swaps prices
(Annual `$79/$119/$199` ↔ Monthly `$99/$149/$249`; Enterprise = Custom) and the sub-note
("Billed annually" ↔ "Billed month-to-month"); 4 tier cards, Growth featured, feature lists per the
repo's `FEATURES_BY_TIER`; then the **expense callout** (teal-tinted framed). `03 FAQ` = native
`<details>` (first item open). Contained teal CTA "Not sure which you need?". (The repo's existing
`BillingProvider` context already drives the toggle — reuse it.)

---

## Interactions & behavior
- **Theme**: `.dark` on `<html>` swaps every `--color-dc-*` token. Use the existing `ThemeToggle`.
  The prototypes' top Light/Dark bar is a preview aid — **do not ship it**.
- **Card hover**: `translateY(-3px)` + deeper shadow, 200ms easeOut. Honor `prefers-reduced-motion`
  (already handled globally in `globals.css`).
- **Pricing billing toggle**: segmented Annual/Monthly control; prices + sub-notes swap. Reuse
  `BillingProvider`. (Prototype animates numerals with a fade — optional, matches existing repo.)
- **Contact form**: client validation, POST to `/api/contact`, then a success panel. Prototype shows
  the success state; keep the repo's real Zod schema + endpoint.
- **FAQ**: disclosure accordion; chevron rotates 180° on open (`details[open] .chev`).
- **Ambient dots**: "Available now" / "Shipping now" use `.animate-heartbeat` (signal-ok);
  "In development" / "Next" use `.animate-calm-pulse` (signal-warn). Both exist in `globals.css`.

## Design tokens (quick reference)
- **Brand**: `#14B8A6` / hover `#0D9488` / dim `#0F766E`. Button ink on teal: `#04110F`.
- **Signals**: ok `#10B981`, warn `#F59E0B`, live `#06B6D4`, urgent `#EF4444`.
- **Radius**: Blueprint panels `4–6px` (sharp); buttons `8–9px`; pills `999px`.
- **Section rhythm**: `padding: clamp(64px,8vw,112px) clamp(20px,5vw,56px)`; every section has a
  `border-top: 1px solid var(--color-dc-edge)` for crisp separation.
- **Type**: h1 `clamp(34px,5vw,62px)` display 700; h2 `clamp(26px,3.4vw,44px)` display 600;
  body `15–16px` sans; mono labels `10–12px`.
- **Shadow (light)**: rest `0 1px 2px rgba(15,17,23,.04), 0 8px 24px -14px rgba(15,17,23,.12)`;
  hover bumps the 2nd layer. **Dark = no shadow, borders only.**
- **Responsive**: prototypes use fluid `clamp()` + `grid-template-columns: repeat(auto-fit,
  minmax(…,1fr))` + `flex-wrap`. In the codebase, use Tailwind responsive variants to the same effect.

## Assets
- **Logo**: existing `BeaconLogo` (teal rounded-square + Podcast glyph). Prototypes redraw it inline;
  use the real component.
- **Icons**: Lucide (per MASTER §9). Prototypes inline Lucide paths; import from `lucide-react`.
- **Founder portrait**: placeholder only — supply Rob's real photo (4:5).
- **Product mockups** (phone PWA, QR sheet, EN/ES SOP, facility readout, engagement brief) are pure
  CSS/markup in the prototypes — recreate as small presentational components, or swap for real
  product screenshots if available.
- No external image assets are required.

## What to ignore in the prototypes (preview-only scaffolding)
- The sticky dark **control bar** at the very top (page label + Light/Dark buttons).
- The **inlined nav and footer** in each file — use `MarketingNav` / `MarketingFooter`.
- `#of-root` scoped token block in each file's `<style>` — the real tokens live in `globals.css`.
- Inline-only styling and the `<x-dc>` wrapper — these are artifacts of the prototype runtime.

## Screenshots
The `screenshots/` folder has light + dark reference captures of every page
(`01-*` = light, `02-*` = dark): home, services, about, contact, tools, pricing. They show the
top/hero of each page — open the matching `.dc.html` for the full scroll.

## Files in this bundle
- `OpsFluency Home.dc.html` — Home (Blueprint)
- `OpsFluency Services.dc.html` — Services
- `OpsFluency About.dc.html` — About
- `OpsFluency Contact.dc.html` — Contact
- `OpsFluency Tools.dc.html` — Tools / Platform
- `OpsFluency Pricing.dc.html` — Pricing
- `README.md` — this document

Open any `.dc.html` in a browser to see the intended design (toggle Light/Dark with the top bar).
